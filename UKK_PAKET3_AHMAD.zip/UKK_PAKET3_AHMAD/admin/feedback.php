<?php
session_start();
require_once "../config/koneksi.php";

$id = $_GET['id'];

if (isset($_POST['kirim_feedback'])) {

    $feedback = $_POST['feedback'];

    $query = "UPDATE pengaduan 
              SET feedback='$feedback' 
              WHERE id='$id'";

    mysqli_query($conn, $query);

    header("Location: dashboard.php");
    exit;
}
?>

<h3>Berikan Feedback</h3>

<form method="POST">
    <textarea name="feedback" required></textarea><br><br>
    <button type="submit" name="kirim_feedback">Kirim</button>
</form>